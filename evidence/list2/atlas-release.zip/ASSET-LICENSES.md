# Asset rights

- media/interior.jpg — bundled photo. Original source, author, and redistribution license are unverified. Replace or confirm the rights before distribution.

Confirm rights for all supplied screenshots, video, external media and content before storefront submission.
