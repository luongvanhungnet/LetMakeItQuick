# itch.io HTML5 pilot checklist

- [ ] Review the [HTML5 upload guide](https://itch.io/docs/creators/html5).
- [ ] Use the itch.io browser ZIP from Launchpad or ZIP the contents of product/ separately. Confirm index.html is at the archive root.
- [ ] Choose HTML as the project type and enable browser playback for the upload.
- [ ] Test responsive behavior, controls, audio, and performance on the itch.io draft page.
- [ ] Add an icon, a description, real screenshots, a promo video, pricing, and license information.
- [ ] Test the customer download before publishing.
