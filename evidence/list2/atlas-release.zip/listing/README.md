# Store listing

The cover is generated from the project name, theme, and available media. Supply actual product screenshots and promo video in the listing kit when available.
