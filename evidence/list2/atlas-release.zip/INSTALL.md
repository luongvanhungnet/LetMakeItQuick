# Install

Extract the package and open product/index.html in a current browser. A 3D game requires WebGL. External links and hosted services may need an internet connection.

This package contains browser HTML. Choose the installable web app export or a separately built native package when a storefront requires one.
